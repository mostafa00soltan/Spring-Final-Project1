package com.example.progect.mapper;

import org.mapstruct.Mapper;

@Mapper
public interface CategoryMapper {

}
