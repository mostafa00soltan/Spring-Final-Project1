package com.example.progect.service;

import com.example.progect.model.CategoryModel;

import java.util.List;

public interface CategoryService {

    List<CategoryModel> getAllCategories();

}
