package com.example.progect.service;

import org.springframework.stereotype.Service;

@Service
public interface ChefsService {
}
