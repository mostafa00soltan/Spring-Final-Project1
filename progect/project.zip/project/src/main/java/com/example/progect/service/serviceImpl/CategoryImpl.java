package com.example.progect.service.serviceImpl;

import com.example.progect.service.CategoryService;
import com.example.progect.service.CategoryService;
import org.springframework.stereotype.Service;

@Service
public class CategoryImpl implements CategoryService {


}
