package com.example.progect.service.serviceImpl;

import com.example.progect.service.ChefsService;
import com.example.progect.service.OrderService;
import org.springframework.stereotype.Service;

@Service
public class ChefsImpl implements ChefsService {
}
