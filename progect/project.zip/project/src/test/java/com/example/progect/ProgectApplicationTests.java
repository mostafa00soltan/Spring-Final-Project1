package com.example.progect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProgectApplicationTests {

	@Test
	void contextLoads() {
	}

}
